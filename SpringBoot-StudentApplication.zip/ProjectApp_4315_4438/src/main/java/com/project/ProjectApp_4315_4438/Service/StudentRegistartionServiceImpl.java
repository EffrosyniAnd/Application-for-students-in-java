package com.project.ProjectApp_4315_4438.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.project.ProjectApp_4315_4438.Dao.StudentRegistrationDAO;
import com.project.ProjectApp_4315_4438.Entity.StudentRegistration;

@Service

public class StudentRegistartionServiceImpl implements StudentRegistrationService {
	
	@Autowired(required = true)//Autowired
	private StudentRegistrationDAO studentRepository;
	
	
	public StudentRegistartionServiceImpl() {
		super();
	}
	@Autowired(required = true)
	public StudentRegistartionServiceImpl(StudentRegistrationDAO theStudentRepository) {
		studentRepository = theStudentRepository;
	}
	
	/*@Override
	@Transactional
	public List<StudentRegistration> findRegistartionbyCourceId(int theId){
		StudentRegistration result = studentRepository.findRegistrationByCourceId(theId);
		
		if (result != null ) {
			return result;
		}
		else {
			// we didn't find the student
			throw new RuntimeException("Did not find studentRegistration  with courceid - " + theId);
		}
	}*/

	@Override
	@Transactional
	public void save(StudentRegistration theStudent) {
		studentRepository.save(theStudent);

	}

	@Override
	@Transactional
	public void deleteById(int thecourceId) {
		studentRepository.deleteById(thecourceId);

	}
	@Override
	@Transactional
	public List<StudentRegistration> findRegistartionbyCourceId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	@Transactional
	public void update(StudentRegistration theStudent) {
		return ;
		
	}
	@Override
	@Transactional
	public List<StudentRegistration> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	@Transactional
	public StudentRegistration findById(int theId) {
		// TODO Auto-generated method stub
		return null;
	}
}
