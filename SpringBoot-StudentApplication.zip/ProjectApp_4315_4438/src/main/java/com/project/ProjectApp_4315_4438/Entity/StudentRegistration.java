package com.project.ProjectApp_4315_4438.Entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class StudentRegistration {
	
	
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="Courceid")
		private int courceid;
		
		@Column(name="first_name")
		private String firstName;
		
		@Column(name="last_name")
		private String lastName;
		
		
		// define constructors
		
		public StudentRegistration() {
			
		}
		
		public StudentRegistration(int courceid, String firstName, String lastName) {
			this.courceid = courceid;
			this.firstName = firstName;
			this.lastName = lastName;
			
		}


		public StudentRegistration(String firstName, String lastName) {
			this.firstName = firstName;
			this.lastName = lastName;
			
		}
		public int getCourceId() {
			return courceid;
		}

		public void setCourceId(int id) {
			this.courceid = id;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		@Override
		public String toString() {
			return "Student [Courceid=" + courceid + ", firstName=" + firstName + ", lastName=" + lastName +  "]";
		}
			
	}
