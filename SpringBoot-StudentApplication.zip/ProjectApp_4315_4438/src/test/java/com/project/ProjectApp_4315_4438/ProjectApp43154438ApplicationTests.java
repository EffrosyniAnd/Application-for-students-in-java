package com.project.ProjectApp_4315_4438;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectApp43154438ApplicationTests {

	@Test
	void contextLoads() {
	}

}
